"""Directory-based storage and visual Image Navigator for Wagtail CMS."""

__version__ = "0.2.1"
